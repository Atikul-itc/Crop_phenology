"""
All paper figures, defined as small functions that each:
  - take a `data_dir` pointing at the project outputs
  - take an `output_dir` to write PDFs/PNGs into
  - produce one figure (matching the outline numbering)

Functions assume the existence of standard files produced by the prior phases.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import Patch

from .style import (apply_style, save, STREAM_COLORS, PHASE_COLORS, PHASE_NAMES,
                     POLICY_COLORS, MAE_CMAP, DIVERGING_CMAP)


PHASES = [10, 12, 15, 18, 19, 21, 24]
STREAMS_ORDERED = ['S1_only', 'S2_only', 'Met_only', 'S1+S2', 'All']
STREAM_LABELS = {'S1_only': 'S1', 'S2_only': 'S2', 'Met_only': 'Met',
                  'S1+S2': 'S1+S2', 'All': 'All'}


# ===========================================================================
# F1 — HGB stream comparison (showing flatness)
# ===========================================================================
def fig1_hgb_streams(data_dir: Path, output_dir: Path):
    """Bar plot of HGB macro MAE per stream × policy. Highlights flatness."""
    rf = pd.read_csv(data_dir / 'phase3_outputs/rf/rf_results_hgb.csv')
    headline = (rf.groupby(['stream','policy'])['mae'].mean()
                 .unstack('policy').reindex(STREAMS_ORDERED))

    fig, ax = plt.subplots(figsize=(5.5, 3.0))
    x = np.arange(len(STREAMS_ORDERED))
    w = 0.4
    ax.bar(x - w/2, headline['all10'], w, label='all10',
           color=POLICY_COLORS['all10'], edgecolor='black', linewidth=0.4)
    ax.bar(x + w/2, headline['rank1'], w, label='rank1',
           color=POLICY_COLORS['rank1'], edgecolor='black', linewidth=0.4)
    ax.set_xticks(x)
    ax.set_xticklabels([STREAM_LABELS[s] for s in STREAMS_ORDERED])
    ax.set_ylabel('Macro MAE (days)')
    ax.set_title('HistGradientBoosting on engineered features')
    ax.legend(frameon=False, loc='lower right')
    ax.set_ylim(0, max(headline.values.max(), 10) * 1.15)
    return save(fig, output_dir, 'F1_hgb_streams')


# ===========================================================================
# F2 — HGB vs LSTM side-by-side
# ===========================================================================
def fig2_hgb_vs_lstm(data_dir: Path, output_dir: Path):
    """Side-by-side bar plot: HGB and LSTM macro MAE per stream (all10 only)."""
    rf = pd.read_csv(data_dir / 'phase3_outputs/rf/rf_results_hgb.csv')
    lstm = pd.read_csv(data_dir / 'phase3_outputs/lstm/lstm_results.csv')

    rf_a = (rf[rf['policy']=='all10'].groupby('stream')['mae'].mean()
              .reindex(STREAMS_ORDERED))
    lstm_a = (lstm[lstm['policy']=='all10'].groupby('stream')['mae'].mean()
                .reindex(STREAMS_ORDERED))

    fig, ax = plt.subplots(figsize=(5.5, 3.2))
    x = np.arange(len(STREAMS_ORDERED))
    w = 0.4
    ax.bar(x - w/2, rf_a,   w, label='HGB',  color='#88CCEE', edgecolor='black', linewidth=0.4)
    ax.bar(x + w/2, lstm_a, w, label='LSTM', color='#332288', edgecolor='black', linewidth=0.4)
    ax.set_xticks(x); ax.set_xticklabels([STREAM_LABELS[s] for s in STREAMS_ORDERED])
    ax.set_ylabel('Macro MAE (days)')
    ax.set_title('Tabular ML (HGB) vs. sequence model (LSTM) — all10 policy')
    ax.legend(frameon=False)
    ax.set_ylim(0, max(rf_a.max(), lstm_a.max()) * 1.15)
    return save(fig, output_dir, 'F2_hgb_vs_lstm')


# ===========================================================================
# F3 — LSTM per-phase × stream heatmap
# ===========================================================================
def fig3_lstm_heatmap(data_dir: Path, output_dir: Path):
    """LSTM per-phase × stream MAE heatmap (all10 policy)."""
    lstm = pd.read_csv(data_dir / 'phase3_outputs/lstm/lstm_results.csv')
    sub = lstm[lstm['policy'] == 'all10']
    table = (sub.groupby(['phase','stream'])['mae'].mean()
                .unstack('stream').reindex(STREAMS_ORDERED, axis=1)
                .reindex(PHASES))

    fig, ax = plt.subplots(figsize=(5.0, 3.6))
    im = ax.imshow(table.values, cmap=MAE_CMAP, aspect='auto',
                    vmin=4, vmax=11)
    ax.set_xticks(range(len(STREAMS_ORDERED)))
    ax.set_xticklabels([STREAM_LABELS[s] for s in STREAMS_ORDERED])
    ax.set_yticks(range(len(PHASES)))
    ax.set_yticklabels([f'{p}: {PHASE_NAMES[p]}' for p in PHASES])
    # Cell annotations
    for i in range(table.shape[0]):
        for j in range(table.shape[1]):
            v = table.values[i, j]
            color = 'white' if v > 7.5 else 'black'
            ax.text(j, i, f'{v:.1f}', ha='center', va='center',
                    fontsize=8, color=color)
    cbar = fig.colorbar(im, ax=ax, fraction=0.04, pad=0.04)
    cbar.set_label('MAE (days)')
    ax.set_title('LSTM phase-resolved performance by stream (all10)')
    return save(fig, output_dir, 'F3_lstm_phase_heatmap')


# ===========================================================================
# F4 — all10-win-rate per phase
# ===========================================================================
def fig4_supervision_winrate(data_dir: Path, output_dir: Path):
    """all10-win-rate per phase across (year, stream) folds."""
    lstm = pd.read_csv(data_dir / 'phase3_outputs/lstm/lstm_results.csv')

    # For each (phase, year, stream), determine winner
    folds = (lstm.groupby(['phase','stream','policy','test_year'])['mae']
                 .first().reset_index())
    pivot = folds.pivot_table(index=['phase','stream','test_year'],
                              columns='policy', values='mae')
    pivot['winner'] = np.where(pivot['all10'] < pivot['rank1'], 'all10', 'rank1')

    # Win rate per phase
    win_rate = (pivot.reset_index().groupby('phase')['winner']
                     .apply(lambda s: (s == 'all10').mean()))
    win_rate = win_rate.reindex(PHASES)

    # Mean MAE Δ (rank1 - all10) per phase
    mae_delta = (folds.groupby(['phase','policy'])['mae'].mean()
                       .unstack('policy'))
    mae_delta['rank1_minus_all10'] = mae_delta['rank1'] - mae_delta['all10']
    delta_per_phase = mae_delta['rank1_minus_all10'].reindex(PHASES)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.0, 3.2),
                                     gridspec_kw={'width_ratios': [1, 1]})
    # Left: win rate
    colors = ['#EE6677' if w < 0.5 else POLICY_COLORS['all10'] for w in win_rate.values]
    bars = ax1.barh([f'{p}' for p in PHASES], win_rate.values * 100,
                      color=colors, edgecolor='black', linewidth=0.4)
    ax1.axvline(50, color='gray', linestyle=':', linewidth=0.8)
    ax1.set_xlim(0, 100)
    ax1.set_xlabel('% of (year × stream) folds\nwhere all10 wins')
    ax1.set_ylabel('BBCH phase')
    ax1.invert_yaxis()
    for bar, val in zip(bars, win_rate.values):
        ax1.text(val*100 + 2, bar.get_y() + bar.get_height()/2,
                 f'{val*100:.0f}%', va='center', fontsize=8)

    # Right: mean MAE delta
    colors2 = ['#EE6677' if d < 0 else POLICY_COLORS['all10'] for d in delta_per_phase.values]
    ax2.barh([f'{p}' for p in PHASES], delta_per_phase.values,
              color=colors2, edgecolor='black', linewidth=0.4)
    ax2.axvline(0, color='black', linewidth=0.8)
    ax2.set_xlabel('Mean MAE difference: rank1 − all10 (days)\n(positive = all10 better)')
    ax2.set_yticklabels([])
    ax2.invert_yaxis()
    for i, val in enumerate(delta_per_phase.values):
        offset = 0.05 if val >= 0 else -0.05
        ha = 'left' if val >= 0 else 'right'
        ax2.text(val + offset, i, f'{val:+.2f}', va='center', ha=ha, fontsize=8)

    fig.suptitle('Supervision strategy: all10 outperforms rank1 for every phase',
                  fontsize=10, y=1.02)
    return save(fig, output_dir, 'F4_supervision_winrate')


# ===========================================================================
# F5 — Attention weight heatmap (MIL variants)
# ===========================================================================
def fig5_attention_heatmap(data_dir: Path, output_dir: Path):
    """Mean attention weights across (slot × phase) for three MIL variants.

    We compute these on the fly from the truncated Part A predictions npz.
    """
    npz_path = data_dir / 'phase4_outputs/mil_partA_predictions.npz'
    if not npz_path.exists():
        # Fallback: try the truncated diagnostic
        # The 04b notebook used a slightly different filename
        candidate = data_dir / 'phase4_outputs/mil_cross_year_predictions.npz'
        if candidate.exists():
            npz_path = candidate
        else:
            print(f'WARN: {npz_path} not found, skipping fig5')
            return None
    z = np.load(npz_path, allow_pickle=False)

    conditions = ['MIL_resolved', 'MIL_shared', 'mean_pool']
    fig, axes = plt.subplots(1, 3, figsize=(8.0, 3.3), sharey=True)
    vmin, vmax = 0.0, 0.20

    for ax, cond in zip(axes, conditions):
        # Find alpha arrays for this condition. Saved keys include
        # '{cond}__All__{year}__alpha'
        alpha_keys = [k for k in z.files
                       if k.startswith(f'{cond}__') and k.endswith('__alpha')]
        if not alpha_keys:
            ax.text(0.5, 0.5, f'No data for\n{cond}',
                    transform=ax.transAxes, ha='center', va='center', fontsize=10)
            ax.set_xticks([]); ax.set_yticks([])
            ax.set_title(cond, fontsize=10)
            continue
        # Concatenate across years and compute mean over bags
        all_alphas = np.concatenate([z[k] for k in alpha_keys], axis=0)
        mean_alpha = all_alphas.mean(axis=0)   # (B_MAX=10, P=7)
        im = ax.imshow(mean_alpha, cmap='Greens', aspect='auto',
                        vmin=vmin, vmax=vmax)
        ax.set_xticks(range(len(PHASES)))
        ax.set_xticklabels([f'{p}' for p in PHASES], rotation=0)
        ax.set_yticks(range(10))
        ax.set_yticklabels([f'slot {i+1}' for i in range(10)])
        ax.set_title(cond, fontsize=10)
        ax.set_xlabel('BBCH phase')
        if ax is axes[0]:
            ax.set_ylabel('Field slot (rank within station)')

    cbar = fig.colorbar(im, ax=axes, shrink=0.8, fraction=0.02, pad=0.02)
    cbar.set_label('Mean attention weight')
    fig.suptitle('Attention pooling: weights are monotonic with rank and '
                  'nearly identical across phases', fontsize=10, y=1.02)
    return save(fig, output_dir, 'F5_attention_heatmap')


# ===========================================================================
# F6 — S1 marginal value × cloudiness × phase
# ===========================================================================
def fig6_cloud_conditional(data_dir: Path, output_dir: Path):
    """S1's marginal value (S2 − S1+S2) by phase and cloudiness stratum.

    Uses per-year terciles as headline; binary cut shown as supplementary panel.
    Computed on the fly from LSTM predictions + per-field S2 obs rates.
    """
    # Load per-field S2 strata
    pf = pd.read_csv(data_dir / 'phase5_outputs/per_field_s2_strata.csv')
    pf = pf.drop_duplicates(subset=['xid', 'year'])

    # Compute per-year strata
    def py_strat(group):
        lo = group.quantile(1/3); hi = group.quantile(2/3)
        return pd.cut(group, [-np.inf, lo, hi, np.inf], labels=['low','med','high'])
    pf['stratum_pyt'] = (pf.groupby('year')['s2_obs_rate']
                            .transform(py_strat))

    # Load LSTM predictions, compute per-field errors, merge with strata
    z = np.load(data_dir / 'phase3_outputs/lstm/lstm_predictions.npz',
                allow_pickle=False)
    rows = []
    for stream in ['S2_only', 'S1+S2']:
        for y in [2017, 2018, 2019, 2020, 2021]:
            pref = f'{stream}__all10__{y}'
            try:
                yt = z[f'{pref}__yt']; yp = z[f'{pref}__yp']; xid = z[f'{pref}__xid']
            except KeyError:
                continue
            for j, phase in enumerate(PHASES):
                valid = (yt[:, j] >= 0) & (yp[:, j] >= 0)
                for i in np.where(valid)[0]:
                    rows.append({'stream': stream, 'phase': int(phase),
                                  'year': int(y), 'xid': int(xid[i]),
                                  'ae': float(abs(yt[i, j] - yp[i, j]))})
    errs = pd.DataFrame(rows).merge(pf[['xid','year','stratum_pyt']],
                                       on=['xid','year'], how='left')
    errs = errs.dropna(subset=['stratum_pyt'])

    # Per-stratum MAE
    agg = (errs.groupby(['phase','stream','stratum_pyt'])['ae']
                .mean().unstack('stream'))
    s1_marg = (agg['S2_only'] - agg['S1+S2']).unstack('stratum_pyt')
    s1_marg = s1_marg[['low', 'med', 'high']]
    s1_marg = s1_marg.reindex(PHASES)

    # Plot
    fig, ax = plt.subplots(figsize=(6.0, 3.6))
    x = np.arange(len(PHASES))
    w = 0.25
    colors_strat = {'low': '#332288', 'med': '#888888', 'high': '#EE7733'}
    labels_strat = {'low': 'Most cloudy (low S2 obs)',
                     'med': 'Medium',
                     'high': 'Least cloudy (high S2 obs)'}
    for i, strat in enumerate(['low', 'med', 'high']):
        ax.bar(x + (i-1)*w, s1_marg[strat].values, w,
                color=colors_strat[strat], edgecolor='black', linewidth=0.4,
                label=labels_strat[strat])
    ax.axhline(0, color='black', linewidth=0.6)
    ax.set_xticks(x)
    ax.set_xticklabels([f'{p}\n{PHASE_NAMES[p]}' for p in PHASES],
                        fontsize=7.5)
    ax.set_ylabel('S1 marginal value: MAE(S2) − MAE(S1+S2)  [days]\n'
                  '(positive = S1 helps)')
    ax.set_title('Sentinel-1 contributes more under sparse Sentinel-2 coverage\n'
                  '(per-year terciles)')
    ax.legend(frameon=False, fontsize=8, loc='upper left')
    return save(fig, output_dir, 'F6_cloud_conditional')


# ===========================================================================
# F9 — Per-year LOYO macro MAE
# ===========================================================================
def fig9_loyo_stability(data_dir: Path, output_dir: Path):
    """Per-year macro MAE for LSTM all10, broken down by stream."""
    lstm = pd.read_csv(data_dir / 'phase3_outputs/lstm/lstm_results.csv')
    sub = lstm[lstm['policy'] == 'all10']

    macro = (sub.groupby(['stream','test_year'])['mae'].mean()
                .unstack('stream').reindex(STREAMS_ORDERED, axis=1))

    fig, ax = plt.subplots(figsize=(5.5, 3.0))
    years = sorted(macro.index)
    x = np.arange(len(years))
    w = 0.16
    for i, stream in enumerate(STREAMS_ORDERED):
        ax.bar(x + (i - 2)*w, macro[stream].reindex(years).values, w,
                label=STREAM_LABELS[stream], color=STREAM_COLORS[stream],
                edgecolor='black', linewidth=0.3)
    ax.set_xticks(x); ax.set_xticklabels([str(y) for y in years])
    ax.set_ylabel('Macro MAE (days)')
    ax.set_xlabel('LOYO test year')
    ax.set_title('LSTM macro MAE per LOYO fold (all10)')
    ax.legend(frameon=False, ncol=3, loc='upper left', fontsize=7.5)
    ax.set_ylim(0, macro.values.max() * 1.15)
    return save(fig, output_dir, 'F9_loyo_stability')


# ===========================================================================
# ENTRY POINT
# ===========================================================================
def make_all(data_dir: str | Path, output_dir: str | Path):
    """Generate all available figures."""
    apply_style()
    data_dir = Path(data_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    results = []
    for name, fn in [('F1', fig1_hgb_streams),
                       ('F2', fig2_hgb_vs_lstm),
                       ('F3', fig3_lstm_heatmap),
                       ('F4', fig4_supervision_winrate),
                       ('F5', fig5_attention_heatmap),
                       ('F6', fig6_cloud_conditional),
                       ('F9', fig9_loyo_stability)]:
        try:
            paths = fn(data_dir, output_dir)
            if paths is None:
                print(f'{name}: skipped (missing data)')
            else:
                print(f'{name}: wrote {paths[0].name} and {paths[1].name}')
            results.append({'figure': name, 'status': 'ok' if paths else 'skipped'})
        except Exception as e:
            print(f'{name}: ERROR — {e}')
            results.append({'figure': name, 'status': f'error: {e}'})
    return pd.DataFrame(results)
