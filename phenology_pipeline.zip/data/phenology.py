"""
Load DWD master phenology file and produce per-(station, harvest_year) phase records.

Key logic (from the audit):
  - The master file's Referenzjahr is the OBSERVATION CALENDAR YEAR, not the harvest year.
  - For HARVEST YEAR Y:
        - Phases {15, 18, 19, 21, 24}: where Referenzjahr == Y  (spring/summer Y)
        - Phases {10, 12}:              where Referenzjahr == Y-1  (autumn Y-1)
  - Apply QB filter (keep Eintrittsdatum_QB in QB_KEEP).
  - Drop duplicates (none expected, but defensive).
  - Drop phase-ordering violations: must have phase_10_date < phase_12_date < phase_15_date < ... <  phase_24_date.
"""
from __future__ import annotations

from pathlib import Path
import numpy as np
import pandas as pd

from .. import config as C
from ..utils import log


def _load_master_raw() -> pd.DataFrame:
    """Read the DWD master CSV with proper dtypes and parse the date."""
    df = pd.read_csv(C.PHENO_MASTER)
    # Eintrittsdatum is YYYYMMDD int
    df["date"] = pd.to_datetime(df["Eintrittsdatum"].astype(str),
                                 format="%Y%m%d", errors="coerce")
    n_bad = df["date"].isna().sum()
    if n_bad:
        log.warning(f"Dropping {n_bad} rows with unparseable Eintrittsdatum")
        df = df.dropna(subset=["date"]).copy()
    # QB filter
    before = len(df)
    df = df[df["Eintrittsdatum_QB"].isin(C.QB_KEEP)].copy()
    log.info(f"QB filter (keep {sorted(C.QB_KEEP)}): {before} -> {len(df)} rows")
    return df


def build_phase_table_for_year(harvest_year: int,
                                master: pd.DataFrame | None = None) -> pd.DataFrame:
    """
    Build a wide table: one row per Stations_i, columns = phase_<id>_date.

    Rules:
      - phases in EARLY_PHASES taken from Referenzjahr = harvest_year - 1
      - other phases taken from Referenzjahr = harvest_year
    """
    if master is None:
        master = _load_master_raw()

    rows = []
    for phase in C.ALL_PHASES:
        ref_year = harvest_year - 1 if phase in C.EARLY_PHASES else harvest_year
        sub = master[(master["Phase_id"] == phase) & (master["Referenzjahr"] == ref_year)]
        sub = sub[["Stations_i", "date"]].rename(columns={"date": f"phase_{phase}_date"})
        # Defensive: drop duplicates if any
        sub = sub.drop_duplicates(subset=["Stations_i"], keep="first")
        rows.append(sub)

    # Merge all phases on Stations_i using outer join (some stations miss some phases)
    out = rows[0]
    for r in rows[1:]:
        out = out.merge(r, on="Stations_i", how="outer")
    out["harvest_year"] = harvest_year

    n_complete = out[[f"phase_{p}_date" for p in C.ALL_PHASES]].notna().all(axis=1).sum()
    log.info(f"harvest_year={harvest_year}: {len(out)} stations, "
             f"{n_complete} with all {len(C.ALL_PHASES)} phases reported")
    return out


def apply_phase_ordering_filter(df: pd.DataFrame, mode: str = "drop") -> pd.DataFrame:
    """
    Enforce phase_10_date < phase_12_date < ... < phase_24_date where all dates are present.

    Stations with any missing phase are NOT filtered (we only filter rows where ALL relevant
    consecutive phases are present and out of order).

    mode='drop'  -> remove the offending row
    mode='nullify' -> set the offending dates to NaT (keep the row, lose those phases)
    """
    df = df.copy()
    cols = [f"phase_{p}_date" for p in C.ALL_PHASES]
    # All pairwise consecutive comparisons must respect strict ordering when both are present.
    bad_mask = pd.Series(False, index=df.index)
    for a, b in zip(cols[:-1], cols[1:]):
        both_present = df[a].notna() & df[b].notna()
        violations = both_present & (df[a] >= df[b])
        bad_mask = bad_mask | violations

    n_bad = bad_mask.sum()
    log.info(f"Phase ordering violations: {n_bad} of {len(df)} rows")
    if mode == "drop":
        return df[~bad_mask].copy()
    elif mode == "nullify":
        # More work: figure out which specific phases to null. For now keep simple
        # and just null all phases for bad rows.
        df.loc[bad_mask, cols] = pd.NaT
        return df
    else:
        raise ValueError(f"Unknown mode: {mode}")


def load_phenology_all_years(harvest_years=range(2017, 2022),
                              ordering_mode: str = "drop") -> pd.DataFrame:
    """
    Load and concatenate the per-station phase tables for all requested harvest years.
    """
    master = _load_master_raw()
    out = []
    for y in harvest_years:
        df = build_phase_table_for_year(y, master=master)
        df = apply_phase_ordering_filter(df, mode=ordering_mode)
        out.append(df)
    full = pd.concat(out, ignore_index=True)
    log.info(f"Total (station, harvest_year) records: {len(full)}")
    return full
