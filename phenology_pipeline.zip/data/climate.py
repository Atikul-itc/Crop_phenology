"""
Load climate data for a harvest year and align to the daily window.

Climate is station-level (one record per (Stations_i, date)). We do not broadcast to
XID here — that happens during dataset assembly to avoid memory blowup.

Notes:
  - We use the closest climate station per phenology station when multiple are present
    (R rdwd output sometimes includes alternates).
  - We RECOMPUTE cumulative_gdd from mean_temp_celsius. The original cumulative_gdd
    column can be all-NaN for a station when any early-season temp is NaN (cumulative
    sum propagates the NaN). Recomputing from temperatures directly fixes that and
    standardizes the formula (base T = config.GDD_BASE_TEMP_C, reset on Jan 1 of
    harvest_year).
"""
from __future__ import annotations
from datetime import date
import numpy as np
import pandas as pd

from .. import config as C
from ..utils import log, harvest_year_window, build_daily_grid


def _recompute_cumulative_gdd(df: pd.DataFrame, harvest_year: int) -> pd.DataFrame:
    """Replace cumulative_gdd with a recomputed value.

    daily_gdd  = max(mean_temp_celsius - GDD_BASE_TEMP_C, 0)  (NaN -> 0 contribution)
    cum_gdd[d] = sum of daily_gdd for d' in [Jan 1 of harvest_year, d]

    df must contain [Stations_i, Date, mean_temp_celsius] and is returned sorted
    by (Stations_i, Date) with cumulative_gdd updated.
    """
    df = df.sort_values(["Stations_i", "Date"]).reset_index(drop=True)
    reset_date = pd.Timestamp(date(harvest_year, *C.GDD_RESET_MONTH_DAY))
    daily = (df["mean_temp_celsius"] - C.GDD_BASE_TEMP_C).clip(lower=0)
    daily = daily.where(df["Date"] >= reset_date, 0.0)
    daily = daily.fillna(0.0).astype(np.float32)
    cum = daily.groupby(df["Stations_i"]).cumsum()
    df["cumulative_gdd"] = cum
    return df


def load_climate_for_year(harvest_year: int) -> pd.DataFrame:
    """Return [Stations_i, Date, <CLIM_FEATURES>, harvest_year] on the daily grid."""
    path = C.climate_csv(harvest_year)
    df = pd.read_csv(path)
    df["Date"] = pd.to_datetime(df["date"], format="%m/%d/%Y", errors="coerce")

    for col in ("mean_temp_celsius", "precipitation_mm"):
        if col not in df.columns:
            raise KeyError(f"Climate file {path} missing required column '{col}'")

    # Dedupe by (Stations_i, Date), keeping the closest climate station if multiple
    if "distance_km" in df.columns:
        n_per_pair = df.groupby(["Stations_i", "Date"]).size()
        n_dup_pairs = int((n_per_pair > 1).sum())
        if n_dup_pairs > 0:
            before = len(df)
            log.warning(f"Climate {harvest_year}: {n_dup_pairs} "
                        f"(Stations_i, Date) pairs have multiple climate stations; "
                        f"keeping the closest.")
            df = (df.sort_values(["Stations_i", "Date", "distance_km"])
                    .drop_duplicates(subset=["Stations_i", "Date"], keep="first"))
            log.info(f"Climate dedupe: {before} -> {len(df)} rows")
    else:
        before = len(df)
        df = df.drop_duplicates(subset=["Stations_i", "Date"], keep="first")
        if len(df) < before:
            log.warning(f"Climate {harvest_year}: dropped {before-len(df)} "
                        f"duplicate (Stations_i, Date) rows.")

    # Recompute cumulative_gdd on observed days (before grid reindexing)
    df = _recompute_cumulative_gdd(df, harvest_year)
    log.info(f"Climate {harvest_year}: cumulative_gdd recomputed "
             f"(base={C.GDD_BASE_TEMP_C}°C, reset on "
             f"{harvest_year}-{C.GDD_RESET_MONTH_DAY[0]:02d}-{C.GDD_RESET_MONTH_DAY[1]:02d})")

    keep = ["Stations_i", "Date"] + C.CLIM_FEATURES
    df = df[keep].copy()

    # Reindex to the full daily grid
    win_start, _, n_days = harvest_year_window(
        harvest_year, C.WINDOW_START_MONTH_DAY, C.WINDOW_END_MONTH_DAY
    )
    grid = build_daily_grid(win_start, n_days)
    stations = df["Stations_i"].unique()
    full_index = pd.MultiIndex.from_product([stations, grid],
                                              names=["Stations_i", "Date"])
    df = (df.set_index(["Stations_i", "Date"])
            .reindex(full_index)
            .reset_index())
    df["harvest_year"] = harvest_year

    nan_counts = df[C.CLIM_FEATURES].isna().sum()
    if nan_counts.sum() > 0:
        log.warning(f"Climate NaNs for {harvest_year} after grid alignment: "
                    f"{nan_counts.to_dict()}")
    log.info(f"Climate for {harvest_year}: {len(stations)} stations × {n_days} days")
    return df
