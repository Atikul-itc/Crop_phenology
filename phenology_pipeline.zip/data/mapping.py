"""
Load the XID ↔ Stations_i ↔ Rank mapping from the per-year metadata files.

We do NOT use phase dates from these files (they have known issues; see audit).
Only the field-to-station mapping is taken from here.
"""
import pandas as pd

from .. import config as C
from ..utils import log


def load_xid_mapping(harvest_year: int) -> pd.DataFrame:
    """Return a DataFrame with columns [XID, Stations_i, Rank, harvest_year]."""
    path = C.metadata_csv(harvest_year)
    df = pd.read_csv(path, usecols=["XID", "Stations_i", "Rank"])
    df = df.drop_duplicates(subset=["XID"])
    df["harvest_year"] = harvest_year
    log.info(f"Mapping {harvest_year}: {len(df)} XIDs across "
             f"{df['Stations_i'].nunique()} stations")
    return df


def load_all_mappings(harvest_years=range(2017, 2022)) -> pd.DataFrame:
    parts = [load_xid_mapping(y) for y in harvest_years]
    full = pd.concat(parts, ignore_index=True)
    # Sanity: a given XID should belong to one Stations_i with one Rank, consistently
    inconsistent = (
        full.groupby("XID")[["Stations_i", "Rank"]]
            .nunique()
            .query("Stations_i > 1 or Rank > 1")
    )
    if len(inconsistent) > 0:
        log.warning(f"{len(inconsistent)} XIDs map inconsistently across years; "
                    "they will appear multiple times in the joined dataset.")
    return full
