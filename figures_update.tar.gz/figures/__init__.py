"""Figure generation package."""
from .style import apply_style
from .figures import make_all
