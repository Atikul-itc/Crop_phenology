"""
Updated paper figures (v2) addressing reflection points:
  - Titles removed (content moves to captions)
  - "all10" / "rank1" replaced with "shared label" / "closest field"
  - DWD phase codes replaced with phase names on tick labels
  - Phase axis labels rotated where they would otherwise clutter
  - F5 panel subtitles renamed to avoid underscores ("Phase-resolved", etc.)
  - F5 colorbar height matched to main plot
  - F6 y-axis title shortened (details to caption)
  - F8 added: example LSTM probability curves vs DWD references

All functions take `data_dir` and `output_dir` and produce one figure as PDF + PNG.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import Patch

from .style import (apply_style, save, STREAM_COLORS, PHASE_COLORS, PHASE_NAMES,
                     POLICY_COLORS, MAE_CMAP, DIVERGING_CMAP)


PHASES = [10, 12, 15, 18, 19, 21, 24]
STREAMS_ORDERED = ['S1_only', 'S2_only', 'Met_only', 'S1+S2', 'All']
STREAM_LABELS = {'S1_only': 'S1', 'S2_only': 'S2', 'Met_only': 'Met',
                  'S1+S2': 'S1+S2', 'All': 'All'}

# Short phase names for tick labels (used when full names would crowd)
PHASE_NAMES_SHORT = {
    10: 'Seeding',
    12: 'Leaf dev.',
    15: 'Stem elong.',
    18: 'Heading',
    19: 'Milk ripe',
    21: 'Yellow ripe',
    24: 'Harvest',
}

# Friendly labels for the supervision policies
POLICY_LABELS = {
    'all10': 'Shared label',
    'rank1': 'Closest field',
}

# Friendly labels for MIL variants (no underscores)
MIL_LABELS = {
    'MIL_resolved': 'Phase-resolved attention',
    'MIL_shared':   'Phase-shared attention',
    'mean_pool':    'Mean pooling',
}


# ===========================================================================
# F1 — HGB stream comparison
# ===========================================================================
def fig1_hgb_streams(data_dir: Path, output_dir: Path):
    """Bar plot of HGB macro MAE per stream and policy.

    Updated: no title (goes to caption), legend at upper-right where it does
    not collide with bars, friendly policy names.
    """
    rf = pd.read_csv(data_dir / 'phase3_outputs/rf/rf_results_hgb.csv')
    headline = (rf.groupby(['stream', 'policy'], observed=True)['mae'].mean()
                  .unstack('policy').reindex(STREAMS_ORDERED))

    fig, ax = plt.subplots(figsize=(5.5, 3.2))
    x = np.arange(len(STREAMS_ORDERED))
    w = 0.38
    ax.bar(x - w/2, headline['all10'], w, label=POLICY_LABELS['all10'],
           color=POLICY_COLORS['all10'], edgecolor='black', linewidth=0.4)
    ax.bar(x + w/2, headline['rank1'], w, label=POLICY_LABELS['rank1'],
           color=POLICY_COLORS['rank1'], edgecolor='black', linewidth=0.4)
    ax.set_xticks(x)
    ax.set_xticklabels([STREAM_LABELS[s] for s in STREAMS_ORDERED])
    ax.set_ylabel('Macro MAE (days)')
    # No title - moves to caption
    # Legend at upper right, outside the bar cluster
    ax.legend(frameon=False, loc='upper right')
    # Give the legend headroom by extending the y-axis a bit more than before
    ax.set_ylim(0, max(headline.values.max(), 10) * 1.25)
    return save(fig, output_dir, 'F1_hgb_streams')


# ===========================================================================
# F2 — HGB vs LSTM side-by-side
# ===========================================================================
def fig2_hgb_vs_lstm(data_dir: Path, output_dir: Path):
    """Side-by-side comparison of HGB and LSTM macro MAE per stream.

    Updated: no title (goes to caption). Legend placement already nice; left as-is.
    """
    rf = pd.read_csv(data_dir / 'phase3_outputs/rf/rf_results_hgb.csv')
    lstm = pd.read_csv(data_dir / 'phase3_outputs/lstm/lstm_results.csv')

    rf_a = (rf[rf['policy'] == 'all10'].groupby('stream', observed=True)['mae']
              .mean().reindex(STREAMS_ORDERED))
    lstm_a = (lstm[lstm['policy'] == 'all10'].groupby('stream', observed=True)['mae']
                .mean().reindex(STREAMS_ORDERED))

    fig, ax = plt.subplots(figsize=(5.5, 3.2))
    x = np.arange(len(STREAMS_ORDERED))
    w = 0.38
    ax.bar(x - w/2, rf_a, w, label='HGB',
            color='#88CCEE', edgecolor='black', linewidth=0.4)
    ax.bar(x + w/2, lstm_a, w, label='LSTM',
            color='#332288', edgecolor='black', linewidth=0.4)
    ax.set_xticks(x)
    ax.set_xticklabels([STREAM_LABELS[s] for s in STREAMS_ORDERED])
    ax.set_ylabel('Macro MAE (days)')
    # No title
    ax.legend(frameon=False)
    ax.set_ylim(0, max(rf_a.max(), lstm_a.max()) * 1.15)
    return save(fig, output_dir, 'F2_hgb_vs_lstm')


# ===========================================================================
# F3 — LSTM per-phase × stream heatmap
# ===========================================================================
def fig3_lstm_heatmap(data_dir: Path, output_dir: Path):
    """LSTM per-phase × stream MAE heatmap.

    Updated: no title, phase names only on y-axis (no DWD numbers).
    """
    lstm = pd.read_csv(data_dir / 'phase3_outputs/lstm/lstm_results.csv')
    sub = lstm[lstm['policy'] == 'all10']
    table = (sub.groupby(['phase', 'stream'], observed=True)['mae'].mean()
                .unstack('stream').reindex(STREAMS_ORDERED, axis=1)
                .reindex(PHASES))

    fig, ax = plt.subplots(figsize=(5.2, 3.6))
    im = ax.imshow(table.values, cmap=MAE_CMAP, aspect='auto', vmin=4, vmax=11)
    ax.set_xticks(range(len(STREAMS_ORDERED)))
    ax.set_xticklabels([STREAM_LABELS[s] for s in STREAMS_ORDERED])
    ax.set_yticks(range(len(PHASES)))
    # Phase names only, no DWD codes
    ax.set_yticklabels([PHASE_NAMES[p] for p in PHASES])
    # Cell annotations
    for i in range(table.shape[0]):
        for j in range(table.shape[1]):
            v = table.values[i, j]
            color = 'white' if v > 7.5 else 'black'
            ax.text(j, i, f'{v:.1f}', ha='center', va='center',
                    fontsize=8, color=color)
    cbar = fig.colorbar(im, ax=ax, fraction=0.04, pad=0.04)
    cbar.set_label('MAE (days)')
    # No title
    return save(fig, output_dir, 'F3_lstm_phase_heatmap')


# ===========================================================================
# F4 — supervision win-rate
# ===========================================================================
def fig4_supervision_winrate(data_dir: Path, output_dir: Path):
    """Win-rate + mean MAE difference for the shared-label policy by phase.

    Updated: no title, phase names on y-axis (not codes), shorter x-axis labels.
    """
    lstm = pd.read_csv(data_dir / 'phase3_outputs/lstm/lstm_results.csv')
    folds = (lstm.groupby(['phase', 'stream', 'policy', 'test_year'], observed=True)['mae']
                 .first().reset_index())
    pivot = folds.pivot_table(index=['phase', 'stream', 'test_year'],
                                columns='policy', values='mae')
    pivot['winner'] = np.where(pivot['all10'] < pivot['rank1'], 'all10', 'rank1')

    win_rate = (pivot.reset_index().groupby('phase', observed=True)['winner']
                      .apply(lambda s: (s == 'all10').mean()))
    win_rate = win_rate.reindex(PHASES)

    mae_delta = (folds.groupby(['phase', 'policy'], observed=True)['mae'].mean()
                       .unstack('policy'))
    mae_delta['rank1_minus_all10'] = mae_delta['rank1'] - mae_delta['all10']
    delta_per_phase = mae_delta['rank1_minus_all10'].reindex(PHASES)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7.4, 3.6),
                                     gridspec_kw={'width_ratios': [1, 1]})

    phase_labels = [PHASE_NAMES[p] for p in PHASES]

    # Left: win rate
    colors = ['#EE6677' if w < 0.5 else POLICY_COLORS['all10']
                for w in win_rate.values]
    bars = ax1.barh(phase_labels, win_rate.values * 100,
                      color=colors, edgecolor='black', linewidth=0.4)
    ax1.axvline(50, color='gray', linestyle=':', linewidth=0.8)
    ax1.set_xlim(0, 100)
    # Short x-axis label - details in caption
    ax1.set_xlabel('Folds favouring shared label (%)')
    ax1.invert_yaxis()
    for bar, val in zip(bars, win_rate.values):
        ax1.text(val * 100 + 2, bar.get_y() + bar.get_height() / 2,
                  f'{val*100:.0f}%', va='center', fontsize=8)

    # Right: mean MAE delta
    colors2 = ['#EE6677' if d < 0 else POLICY_COLORS['all10']
                 for d in delta_per_phase.values]
    ax2.barh(phase_labels, delta_per_phase.values,
              color=colors2, edgecolor='black', linewidth=0.4)
    ax2.axvline(0, color='black', linewidth=0.8)
    # Short x-axis label
    ax2.set_xlabel('Closest minus shared MAE (days)')
    ax2.set_yticklabels([])
    ax2.invert_yaxis()
    for i, val in enumerate(delta_per_phase.values):
        offset = 0.05 if val >= 0 else -0.05
        ha = 'left' if val >= 0 else 'right'
        ax2.text(val + offset, i, f'{val:+.2f}', va='center', ha=ha, fontsize=8)

    # No title
    return save(fig, output_dir, 'F4_supervision_winrate')


# ===========================================================================
# F5 — Attention weight heatmap (MIL variants)
# ===========================================================================
def fig5_attention_heatmap(data_dir: Path, output_dir: Path):
    """Mean attention weights across (slot × phase) for three MIL variants.

    Updated: no title, friendly panel subtitles, rotated phase-name x-tick labels,
    colorbar height matched to plot.
    """
    npz_path = data_dir / 'phase4_outputs/mil_partA_predictions.npz'
    if not npz_path.exists():
        candidate = data_dir / 'phase4_outputs/mil_cross_year_predictions.npz'
        if candidate.exists():
            npz_path = candidate
        else:
            print(f'WARN: {npz_path} not found, skipping fig5')
            return None
    z = np.load(npz_path, allow_pickle=False)

    conditions = ['MIL_resolved', 'MIL_shared', 'mean_pool']
    # Slightly taller for the rotated x labels
    fig, axes = plt.subplots(1, 3, figsize=(8.4, 3.8), sharey=True)
    vmin, vmax = 0.0, 0.20
    im = None

    for ax, cond in zip(axes, conditions):
        alpha_keys = [k for k in z.files
                       if k.startswith(f'{cond}__') and k.endswith('__alpha')]
        if not alpha_keys:
            ax.text(0.5, 0.5, f'No data for\n{MIL_LABELS[cond]}',
                     transform=ax.transAxes, ha='center', va='center', fontsize=10)
            ax.set_xticks([]); ax.set_yticks([])
            ax.set_title(MIL_LABELS[cond], fontsize=10)
            continue
        all_alphas = np.concatenate([z[k] for k in alpha_keys], axis=0)
        mean_alpha = all_alphas.mean(axis=0)
        im = ax.imshow(mean_alpha, cmap='Greens', aspect='auto',
                        vmin=vmin, vmax=vmax)
        ax.set_xticks(range(len(PHASES)))
        # Phase names, rotated 90 degrees
        ax.set_xticklabels([PHASE_NAMES_SHORT[p] for p in PHASES],
                            rotation=90)
        ax.set_yticks(range(10))
        ax.set_yticklabels([f'slot {i+1}' for i in range(10)])
        ax.set_title(MIL_LABELS[cond], fontsize=10)
        if ax is axes[0]:
            ax.set_ylabel('Field slot (rank within station)')

    # Colorbar matched to plot height: place to the right of the rightmost axes
    if im is not None:
        fig.subplots_adjust(right=0.88)
        cax = fig.add_axes([0.90, axes[-1].get_position().y0,
                              0.018,
                              axes[-1].get_position().height])
        cbar = fig.colorbar(im, cax=cax)
        cbar.set_label('Mean attention weight')

    # No title (caption explains)
    return save(fig, output_dir, 'F5_attention_heatmap')


# ===========================================================================
# F6 — Cloud-conditional S1 marginal value
# ===========================================================================
def fig6_cloud_conditional(data_dir: Path, output_dir: Path):
    """Sentinel-1's marginal value by phase and cloudiness stratum (per-year terciles).

    Updated: no title, shorter y-axis label, phase names rotated on x-axis.
    """
    pf = pd.read_csv(data_dir / 'phase5_outputs/per_field_s2_strata.csv')
    pf = pf.drop_duplicates(subset=['xid', 'year'])

    def py_strat(group):
        lo = group.quantile(1/3); hi = group.quantile(2/3)
        return pd.cut(group, [-np.inf, lo, hi, np.inf], labels=['low', 'med', 'high'])
    pf['stratum_pyt'] = (pf.groupby('year', observed=True)['s2_obs_rate']
                            .transform(py_strat))

    z = np.load(data_dir / 'phase3_outputs/lstm/lstm_predictions.npz',
                allow_pickle=False)
    rows = []
    for stream in ['S2_only', 'S1+S2']:
        for y in [2017, 2018, 2019, 2020, 2021]:
            pref = f'{stream}__all10__{y}'
            try:
                yt = z[f'{pref}__yt']; yp = z[f'{pref}__yp']; xid = z[f'{pref}__xid']
            except KeyError:
                continue
            for j, phase in enumerate(PHASES):
                valid = (yt[:, j] >= 0) & (yp[:, j] >= 0)
                for i in np.where(valid)[0]:
                    rows.append({'stream': stream, 'phase': int(phase),
                                  'year': int(y), 'xid': int(xid[i]),
                                  'ae': float(abs(yt[i, j] - yp[i, j]))})
    errs = pd.DataFrame(rows).merge(pf[['xid', 'year', 'stratum_pyt']],
                                       on=['xid', 'year'], how='left')
    errs = errs.dropna(subset=['stratum_pyt'])

    agg = (errs.groupby(['phase', 'stream', 'stratum_pyt'], observed=True)['ae']
                .mean().unstack('stream'))
    s1_marg = (agg['S2_only'] - agg['S1+S2']).unstack('stratum_pyt')
    s1_marg = s1_marg[['low', 'med', 'high']]
    s1_marg = s1_marg.reindex(PHASES)

    fig, ax = plt.subplots(figsize=(6.5, 3.8))
    x = np.arange(len(PHASES))
    w = 0.25
    colors_strat = {'low': '#332288', 'med': '#888888', 'high': '#EE7733'}
    labels_strat = {'low': 'Most cloudy',
                     'med': 'Medium',
                     'high': 'Least cloudy'}
    for i, strat in enumerate(['low', 'med', 'high']):
        ax.bar(x + (i-1)*w, s1_marg[strat].values, w,
                color=colors_strat[strat], edgecolor='black', linewidth=0.4,
                label=labels_strat[strat])
    ax.axhline(0, color='black', linewidth=0.6)
    ax.set_xticks(x)
    # Phase names rotated, no DWD codes
    ax.set_xticklabels([PHASE_NAMES_SHORT[p] for p in PHASES], rotation=90)
    # Shorter y label
    ax.set_ylabel('S1 marginal value (days)')
    # No title
    ax.legend(frameon=False, fontsize=8, loc='upper left')
    return save(fig, output_dir, 'F6_cloud_conditional')


# ===========================================================================
# F8 — Example LSTM probability curves vs DWD references
# ===========================================================================
def fig8_example_curves(data_dir: Path, output_dir: Path,
                          phase_to_plot: int = 24,
                          fold_year: int = 2020,
                          rng_seed: int = 7):
    """Show per-day phase-probability curves for four representative fields.

    For each selected field, plot:
      - the predicted per-day probabilities for all 7 phases (one curve each)
      - the DWD reference dates as vertical dashed lines (phase coloured)
      - the predicted day (argmax) for each phase as a small triangle

    The four fields are selected to span the range of prediction quality
    for phase_to_plot (default: harvest):
      - "Best": smallest error
      - "Typical": at the 33rd percentile of error
      - "Poor": at the 67th percentile of error
      - "Worst": largest error

    Needs per-day phase logits saved to `lstm_logits.npz`. See the
    accompanying notebook for the snippet to generate this file from your
    existing trained LSTM checkpoints.
    """
    logits_npz = data_dir / 'phase3_outputs/lstm/lstm_logits.npz'
    if not logits_npz.exists():
        print(f'NOTE: {logits_npz} not found. Generate with the F8 add-on cell.')
        return None

    z = np.load(logits_npz, allow_pickle=False)

    pref = f'All__all10__{fold_year}'
    try:
        logits = z[f'{pref}__logits']
        yt = z[f'{pref}__yt']
        xid = z[f'{pref}__xid']
        bagid = z[f'{pref}__bag']
    except KeyError as e:
        print(f'NOTE: per-day logits for {pref} not found in npz. Key error: {e}')
        return None

    j = PHASES.index(phase_to_plot)
    valid = (yt[:, j] >= 0)
    preds = logits[:, :, j].argmax(axis=1)
    errors = np.abs(preds - yt[:, j])
    errors_f = errors.astype(float)
    errors_f[~valid] = np.nan

    valid_idx = np.where(valid)[0]
    if len(valid_idx) < 4:
        print('NOTE: too few valid records to select 4 examples; skipping F8.')
        return None

    err_valid = errors[valid_idx]
    sort_order = np.argsort(err_valid)
    quantile_picks = [
        sort_order[0],
        sort_order[len(sort_order)//3],
        sort_order[2 * len(sort_order)//3],
        sort_order[-1],
    ]
    picks = [valid_idx[i] for i in quantile_picks]
    pick_labels = ['Best', 'Typical', 'Poor', 'Worst']

    def sigmoid(x):
        return 1.0 / (1.0 + np.exp(-x))

    T = logits.shape[1]
    days = np.arange(T)
    month_ticks_days = [0, 61, 122, 181, 242, 305, 365, 426]
    month_ticks_labels = ['Sep', 'Nov', 'Jan', 'Mar', 'May', 'Jul', 'Sep', 'Oct']

    fig, axes = plt.subplots(2, 2, figsize=(8.0, 5.8), sharex=True)
    axes = axes.flatten()

    for ax, idx, label in zip(axes, picks, pick_labels):
        for jj, phase in enumerate(PHASES):
            p = sigmoid(logits[idx, :, jj])
            ax.plot(days, p, color=PHASE_COLORS[phase],
                     linewidth=1.0, alpha=0.85,
                     label=PHASE_NAMES_SHORT[phase])
            arg = int(p.argmax())
            ax.scatter([arg], [p[arg]], marker='v', s=18,
                        color=PHASE_COLORS[phase], edgecolors='black',
                        linewidth=0.4, zorder=4)
            ref = int(yt[idx, jj])
            if ref >= 0:
                ax.axvline(ref, color=PHASE_COLORS[phase],
                            linestyle=':', linewidth=0.6, alpha=0.7)

        ax.set_xticks(month_ticks_days)
        ax.set_xticklabels(month_ticks_labels)
        ax.set_xlim(0, T)
        ax.set_ylim(0, 1.05)
        err_d = int(errors[idx])
        panel_title = (f'{label} (XID {int(xid[idx])}): '
                        f'{PHASE_NAMES_SHORT[phase_to_plot]} '
                        f'error {err_d} d')
        ax.set_title(panel_title, fontsize=9)
        if ax in (axes[0], axes[2]):
            ax.set_ylabel('Phase probability')

    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='lower center', ncol=7,
                frameon=False, fontsize=8, bbox_to_anchor=(0.5, -0.02))

    fig.subplots_adjust(bottom=0.13, hspace=0.30)
    return save(fig, output_dir, 'F8_example_curves')


# ===========================================================================
# F9 — Per-year LOYO stability
# ===========================================================================
def fig9_loyo_stability(data_dir: Path, output_dir: Path):
    """Per-year macro MAE for LSTM shared-label policy, by stream.

    Updated: no title.
    """
    lstm = pd.read_csv(data_dir / 'phase3_outputs/lstm/lstm_results.csv')
    sub = lstm[lstm['policy'] == 'all10']

    macro = (sub.groupby(['stream', 'test_year'], observed=True)['mae'].mean()
                .unstack('stream').reindex(STREAMS_ORDERED, axis=1))

    fig, ax = plt.subplots(figsize=(5.5, 3.2))
    years = sorted(macro.index)
    x = np.arange(len(years))
    w = 0.16
    for i, stream in enumerate(STREAMS_ORDERED):
        ax.bar(x + (i - 2)*w, macro[stream].reindex(years).values, w,
                label=STREAM_LABELS[stream], color=STREAM_COLORS[stream],
                edgecolor='black', linewidth=0.3)
    ax.set_xticks(x); ax.set_xticklabels([str(y) for y in years])
    ax.set_ylabel('Macro MAE (days)')
    ax.set_xlabel('Leave-one-year-out test year')
    # No title
    ax.legend(frameon=False, ncol=3, loc='upper left', fontsize=7.5)
    ax.set_ylim(0, macro.values.max() * 1.15)
    return save(fig, output_dir, 'F9_loyo_stability')


# ===========================================================================
# ENTRY POINT
# ===========================================================================
def make_all(data_dir, output_dir):
    """Generate all available figures."""
    apply_style()
    data_dir = Path(data_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    results = []
    targets = [
        ('F1', fig1_hgb_streams),
        ('F2', fig2_hgb_vs_lstm),
        ('F3', fig3_lstm_heatmap),
        ('F4', fig4_supervision_winrate),
        ('F5', fig5_attention_heatmap),
        ('F6', fig6_cloud_conditional),
        ('F8', fig8_example_curves),
        ('F9', fig9_loyo_stability),
    ]
    for name, fn in targets:
        try:
            paths = fn(data_dir, output_dir)
            if paths is None:
                print(f'{name}: skipped (missing data)')
                results.append({'figure': name, 'status': 'skipped'})
            else:
                print(f'{name}: wrote {paths[0].name} and {paths[1].name}')
                results.append({'figure': name, 'status': 'ok'})
        except Exception as e:
            print(f'{name}: ERROR — {e}')
            results.append({'figure': name, 'status': f'error: {e}'})
    return pd.DataFrame(results)
