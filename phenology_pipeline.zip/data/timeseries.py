"""
Load S1 and S2 feature CSVs and pivot to wide format:
    one row per (XID, Date), columns = each feature.

The raw long format has NaN-filled daily rows for ALL dates in the window; we keep
that structure so the model sees a regular daily grid with masks.
"""
from pathlib import Path
import numpy as np
import pandas as pd

from .. import config as C
from ..utils import log, harvest_year_window, build_daily_grid, parquet_cache


def _load_one_feature(path: Path, feature: str) -> pd.DataFrame:
    """Read one feature CSV and return [XID, Date, <feature>]. Stations_i/Rank dropped.

    Defensively drops duplicate (XID, Date) rows if any exist.
    """
    df = pd.read_csv(path, usecols=["XID", "Date", feature])
    df["Date"] = pd.to_datetime(df["Date"], format="%Y-%m-%d", errors="coerce")
    before = len(df)
    df = df.drop_duplicates(subset=["XID", "Date"], keep="first")
    if len(df) < before:
        log.warning(f"{path.name}: dropped {before-len(df)} duplicate (XID, Date) rows")
    return df


def build_rs_wide_for_year(harvest_year: int,
                            s2_features=None,
                            s1_features=None,
                            require_all_features: bool = True) -> pd.DataFrame:
    """
    Build a wide (XID, Date) -> features table for one harvest year.

    The function:
      - Loads each requested S2 and S1 feature.
      - Outer-merges them on (XID, Date).
      - Ensures the full daily grid [(Y-1)-09-01 .. Y-10-31] is present for every XID.
      - Returns columns: [XID, Date, <all features>]

    NaN means "no observation on that day" — preserved for downstream masking.
    """
    s2_features = s2_features or C.S2_FEATURES
    s1_features = s1_features or C.S1_FEATURES

    pieces = []
    missing_files = []
    for feat in s2_features:
        p = C.s2_csv(feat, harvest_year)
        if not p.exists():
            missing_files.append(str(p))
            continue
        pieces.append(_load_one_feature(p, feat))
    for feat in s1_features:
        p = C.s1_csv(feat, harvest_year)
        if not p.exists():
            missing_files.append(str(p))
            continue
        pieces.append(_load_one_feature(p, feat))

    if missing_files:
        msg = f"Missing {len(missing_files)} feature files for {harvest_year}: " \
              f"{missing_files[:3]}{'...' if len(missing_files)>3 else ''}"
        if require_all_features:
            raise FileNotFoundError(msg)
        else:
            log.warning(msg)

    # Merge all features on (XID, Date)
    out = pieces[0]
    for p in pieces[1:]:
        out = out.merge(p, on=["XID", "Date"], how="outer")

    # Reindex onto the full daily grid for each XID
    win_start, _, n_days = harvest_year_window(
        harvest_year, C.WINDOW_START_MONTH_DAY, C.WINDOW_END_MONTH_DAY
    )
    grid = build_daily_grid(win_start, n_days)
    xids = out["XID"].unique()
    full_index = pd.MultiIndex.from_product([xids, grid], names=["XID", "Date"])
    out = (out.set_index(["XID", "Date"])
              .reindex(full_index)
              .reset_index())
    out["harvest_year"] = harvest_year
    log.info(f"RS wide table for {harvest_year}: "
             f"{len(xids)} XIDs × {n_days} days = {len(out)} rows, "
             f"{out.shape[1]-3} feature columns")
    return out
